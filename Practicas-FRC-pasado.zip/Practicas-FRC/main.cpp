#include "interfaz.hpp"

int main(){
    int grupo;
    
    printf("----------------------------\n");
    printf("------ SESION 5 - FRC ------\n");
    printf("----------------------------\n");

    interface_t iface;

    //Sesion 1
    mostrarYSeleccionarInterfaz(&iface);

    //Sesion 2
    abrirAdaptador(&iface);

    //Información de la Sesion21
    Metadata metadata = {
        {0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, // mac_src
        {0x00, 0x01, 0x02, 0x03, 0x04, 0x05}, // mac_dst
        {0x30, 0x00}                          // type
    };

    cambiarMACOrigen(&metadata, iface.MACaddr);

    printf("La MAC es: "); mostrarMACOrigen(&metadata);

    //Sesion 3
    grupo=seleccinarGrupo(&metadata);
    printf("\n");
    bool esMaestro = seleccionarModo(&iface, &metadata,grupo);

    //Sesion 3 y 4
    seleccionarYEjecutarFuncion(&iface, &metadata, esMaestro);
    
    return 0;
}