#include "esclavo.hpp"
#include "comunes.hpp"

using namespace std;

void pdEsclavo(interface_t *iface, int g, int n, Metadata *metadata)
{

    metadata->type[0] = 0x30 + g; // cambia con el grupo
    metadata->type[1] = 0x02;


    printf("Esperando que se una la estación maestra\n");

    // RECIBIMOS LA TRAMA DEL BROADCAST Y FILTRAMOS PARA TENER LA QUE QUERAMOS

    bool end = false;

    while (!end)
    {
        assembled_Packet trama = ReceiveFrame(iface);
        const unsigned char *data = trama.packet;
        if (data)
        { // mientras recibimos
            if (trama.packet[12] == metadata->type[0] && trama.packet[13] == 0x01)
            {
                for (int i = 0; i < 6; i++)
                {
                    metadata->mac_dst[i] = trama.packet[i + 6];
                }
                printf("Estación encontrada\n");
                mostrarMACDestino(&metadata);
                end = true;
            }
        }
    }

    // UNA VEZ ENCONTRADA MANDAMOS UN MENSAJE A ESA DIRECCION PARA QUE NOS DESCUBRA
    unsigned char *tramaDescubrimiento = BuildHeader(metadata->mac_src, metadata->mac_dst, metadata->type);
    SendFrame(iface, tramaDescubrimiento, 0);
    free(tramaDescubrimiento);

    metadata->type[1] = 0x00;

    int error = 0;
    seleccion(n, iface, &metadata, error);
}

void paroYEsperaEsclavo(interface_t *iface, Metadata *metadata)
{
    // el esclavo espera recibir trama de control de maestro y si esta listo le manda una trama de control aceptando que esta listo

    unsigned char vectorControl[3];

    char numTrama = '0';

    unsigned char bce;

    bool end = false;

    // esperamos a que recibir trama de maestro
    while (!end)
    {
        bool fuera = false;
        assembled_Packet trama = ReceiveFrame(iface);
        while (!fuera)
        {
            if (trama.packet)
            { // mientras recibimos
                if (trama.packet[14] == 'R' && trama.packet[15] == 05 && trama.packet[16] == '0')
                { // establecimiento
                    printf("R   R   ENQ    0\n");
                    vectorControl[0] = 'R';
                    vectorControl[1] = 06;
                    vectorControl[2] = trama.packet[16];

                    unsigned char *tramaControlEstablecimiento = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, vectorControl);
                    SendFrame(iface, tramaControlEstablecimiento, 3);
                    printf("E   R   ACK    0\n");
                    printf("\n");
                    free(tramaControlEstablecimiento);
                    fuera = true;
                }
                else if (trama.packet[14] == 'R' && trama.packet[15] == 02 && trama.packet[16] == numTrama)
                { // transferencia
                    char cad[255];
                    for (int i = 0; i < trama.packet[17]; i++)
                    {
                        cad[i] = trama.packet[18 + i];
                    }
                    cad[trama.packet[17]] = '\0';

                    bce = calculoBCE(cad);

                    int tam = trama.packet[17] + 18;

                    printf("R   %c   STX   %c   %u   %u\n", trama.packet[14], trama.packet[16], trama.packet[tam], bce);
                    if (bce == trama.packet[tam])
                    {
                        char datos[255];
                        for (int i = 0; i < trama.packet[17]; i++)
                        {
                            datos[i] = trama.packet[18 + i];
                        }
                        string nombre = "RProtoc.txt";
                        escribirFichero(nombre, datos);
                        vectorControl[0] = 'R';
                        vectorControl[1] = 06;
                        vectorControl[2] = trama.packet[16];
                        unsigned char *tramaControlTranferencia = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, vectorControl);
                        SendFrame(iface, tramaControlTranferencia, 3);
                        printf("E   %c   ACK   %c   \n", vectorControl[0], vectorControl[2]);
                        free(tramaControlTranferencia);
                        if (numTrama == '0')
                        {
                            numTrama = '1';
                        }
                        else
                        {
                            numTrama = '0';
                        }
                        fuera = true;
                    }
                    else
                    {
                        vectorControl[0] = 'R';
                        vectorControl[1] = 21;
                        vectorControl[2] = trama.packet[16];

                        unsigned char *tramaControlTransferencia = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, vectorControl);
                        SendFrame(iface, tramaControlTransferencia, 3);
                        printf("E   %c   NACK  %c\n", vectorControl[0], vectorControl[2]);
                        free(tramaControlTransferencia);
                        // retransmision

                        fuera = true;
                    }
                }
                else if (trama.packet[14] == 'R' && trama.packet[15] == 04 && trama.packet[16] == '0')
                {
                    vectorControl[0] = 'R';
                    vectorControl[1] = 06;
                    vectorControl[2] = trama.packet[16];
                    printf("\n");
                    printf("R   %c   EOT   %c\n", vectorControl[0], vectorControl[2]);

                    unsigned char *tramaControlLiberacion = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, vectorControl);
                    SendFrame(iface, tramaControlLiberacion, 3);
                    printf("E   %c   ACK   %c\n", vectorControl[0], vectorControl[2]);
                    free(tramaControlLiberacion);
                    fuera = true;
                    end = true;
                }
            }
            else
            {
                fuera = true;
            }
        }
    }
}

void escribirFichero(string &nombre, char datos[])
{
    ofstream fichero;

    // Abrir el fichero en modo añadir
    fichero.open(nombre, std::ios::app);

    if (!fichero)
    {
        std::cerr << "Error al abrir el fichero: " << nombre << std::endl;
        return;
    }

    // Escribir la cadena en el fichero, seguido de un salto de línea
    fichero << datos << std::endl;

    // Cerrar el fichero
    fichero.close();
}