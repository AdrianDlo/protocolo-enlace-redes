#include <stdio.h>
#include <iostream>
#include "linkLayer.h"
#include <string>
#include <stdio_ext.h>
#include <fstream>
#include "claseMac.hpp"

#ifndef COMUNES_H
#define COMUNES_H

// ABRE EL PUERTO PARA PERMITIR LA COMUNICACION
int abrirPuerto(interface_t *iface);
// CIERRA EL PUERTO PARA TERMINAR LA COMUNICACION
int cerrarPuerto(interface_t *iface);
// MUESTRA LAS INTERFACES DISPONIBLES
void mostrarInterfacesDisponibles(pcap_if_t *avail_ifaces);
// SELECCIONA LA INTERFAZ ELEGIDA
void seleccionarInterfaz(pcap_if_t *avail_ifaces, interface_t *iface);

// SELECCIONA EL GRUPO ELEGIDO
int seleccionarGrupo(Metadata *metadata);
// SELECCIONA ENTRE MODO MAESTRO/ESCLAVO
void seleccionarModo(interface_t *iface, int g,Metadata *metadata);
// ENVIA UNA TRAMA DE DATOS
void enviarTrama(interface_t *iface, char *car, Metadata *metadata);
// RECIBE UN CARACTER DE OTRA INTEFAZ
char recibirCaracter(interface_t *iface, unsigned char type[2]);
// ENVIO DE CARACTERES INTERACTIVOS (CHAT) ENTRE MAESTRO Y ESCLAVO
void envioCaracteresInteractivo(interface_t *iface,Metadata *metadata);
// RECIBE UNA CADENA COMPLETA
int recibirCadena(interface_t *iface, Metadata *metadata,char cadena[255]);
// CALCULA EL BCE
unsigned char calculoBCE(char cad[255]);
// BORRA EL CONTENIDO PREVIO DEL FICHERO "RPROTOC.TXT"
void borrarFichero();
// MENU DE SELECCION DE OPCIONES DE MAESTRO/ESCLAVO
void seleccion(int n, interface_t *iface, Metadata *metadata, int &error);

// DECLARACION DE CABECERAS PARA USAR METODOS DE ESCLAVO Y MAESTRO
// ESTO ES DEBIDO A QUE NO PODEMOS HACER INCLUDE PUESTO Q HABRIA INCLUDES CICLICOS Y SALTA EL ERROR: "MAESTRO.H SE INLCUYE A SI MISMO"//"ESCLAVO.H SE INCLUYE A SI MISMO"
// MAESTRO
void envioDeFichero(interface_t *iface, Metadata *metadata);
void establecimientoMaestro(interface_t *iface, Metadata *metadata);
void transferenciaMaestro(interface_t *iface, Metadata *metadata, int &error);
void liberacionMaestro(interface_t *iface, Metadata *metadata);
void pdMaestro(interface_t *iface, int g, int n);

// ESCLAVO
void pdEsclavo(interface_t *iface, int g, int n,Metadata *metadata);
void paroYEsperaEsclavo(interface_t *iface, Metadata *metadata);

#endif