//============================================================================
// ----------- PRACTICAS DE FUNDAMENTOS DE REDES DE COMUNICACIONES -----------
// ---------------------------- CURSO 2025/26 --------------------------------
// ----------------------------- SESION1.CPP ---------------------------------
//============================================================================

/*AUTORES:
Grupo 3
*Adrián de la Osa García
Sergio Sánchez Amado
*/
#include <stdio.h>
#include <iostream>
#include "linkLayer.h"
#include <string>
#include <stdio_ext.h>
#include <fstream>

#include "comunes.hpp"

using namespace std;

int main()
{
 Metadata metadata = {
        {0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, // mac_src
        {0x00, 0x01, 0x02, 0x03, 0x04, 0x05}, // mac_dst
        {0x30, 0x00}                          // type
    };

    interface_t iface;
    pcap_if_t *avail_ifaces = NULL;

    avail_ifaces = GetAvailAdapters();
    
    mostrarInterfacesDisponibles(avail_ifaces);
    seleccionarInterfaz(avail_ifaces, &iface);
    cambiarMACOrigen(&metadata, iface.MACaddr); // Añadimos nuestra MAC a la estructura metadata para tener la MAC origen
    mostrarMACorigen(&metadata);
    // SELECCIONAMOS EL GRUPO QUE QUERAMOS
    int g = seleccionarGrupo();
    // ABRIMOS EL PUERTO PARA PODER COMUNICARNOS
    abrirPuerto(&iface);
    // BORRAMOS EL CONTENIDO PREVIO DE RPROTOC
    borrarFichero();
    // SELECCIONAMOS EL MODO DE LA ESTACION
    seleccionarModo(&iface, g, &metadata);
    // HEMOS TERMINADO -->CERRAMOS EL PUERTO
    cerrarPuerto(&iface);

    // FIN DE DESCUBRIMIENTO TIPO[2] TIENE QUE SER 0

    // HACER LIBRERIAS .H/.CPP
    // RECIBIR FICHERO RECIBE LAS TRAMAS DESORDENADAS (ES ASI EN UNA RED, EN EL SCRIPT NO) (DEJARLO ASI)

    return 0;
}