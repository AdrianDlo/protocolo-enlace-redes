#include "comunes.hpp"

using namespace std;

int abrirPuerto(interface_t *iface)
{
    int puerto = OpenAdapter(iface);
    if (puerto != 0)
    {
        printf("Error al abrir el puerto\n");
        getch();
        return (1);
    }
    else
        printf("Puerto abierto correctamente\n");
    return 0;
}

int cerrarPuerto(interface_t *iface)
{
    CloseAdapter(iface);
    printf("Puerto cerrado\n");
    return 0;
}

void mostrarInterfacesDisponibles(pcap_if_t *avail_ifaces)
{
    // recorremos las interfaces para poder mostrarlas todas
    int i = 0

    while(avail_ifaces != nullptr)
    {
        cout << "[" << i << "]" << avail_ifaces->name << endl;
        avail_ifaces = avail_ifaces->next;
        i++;
    }
}

void seleccionarInterfaz(pcap_if_t *avail_ifaces, interface_t *iface)
{
    cout << "Seleccione interfaz: ";
    int n;
    cin >> n;

    // Mostrar nombre de interfaz seleccionada
    for (int j = 1; j <= n; j++)
    {
        avail_ifaces = avail_ifaces->next;
    }
    cout << "Interfaz Elegida :" << avail_ifaces->name << endl;
    setDeviceName(iface, avail_ifaces->name);
    GetMACAdapter(iface);
}



int seleccionarGrupo(Metadata *metadata)
{
    printf("Introduzca el numero de grupo:\n");
    int grupo;
    cin >> grupo;
    metadata->type[0] = 0x30 + grupo;
    return grupo;

}

void seleccionarModo(interface_t *iface, int g,Metadata *metadata)
{
    int n;
    char numTrama = '0';
    printf("Selección el modo de la estación\n");
    printf("[1] Modo Maestro\n");
    printf("[2] Modo Esclavo\n");
    cin >> n; // modo
    if (n != 27)
    {
        if (n == 1) // si n =1 es maestro
        {
            pdMaestro(iface, g, n,&metadata);
        }
        else if (n == 2)// si n =2 es esclavo
        {
            pdEsclavo(iface, g, n,&metadata);
        }
    }
}
void enviarTrama(interface_t *iface, char *car, Metadata *metadata)
{
    unsigned char *tramaEnviada = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, (unsigned char *)car);
    SendFrame(iface, tramaEnviada, 1);
    free(tramaEnviada);
}

char recibirCaracter(interface_t *iface, unsigned char type[2])
{
    // char car;
    assembled_Packet tramaRecibida = ReceiveFrame(iface);
    int tam = tramaRecibida.header.len - 14;          // tamaño del paquete :  macsrc(6), macdst(6), type(2), datos(resto)
    const unsigned char *data = tramaRecibida.packet; // paquete de X tamaño
    if (data)
    {
        if (data[12] == type[0] && data[13] == 0x00)
        {
            printf("Caracteres recibidos: %i\n", tam);
            return data[14];
        }
    }
    return 0;
}

void envioCaracteresInteractivo(interface_t *iface, Metadata *metadata)
{
    char tecla;
    __fpurge(stdin);
    cout << "Pulse los caracteres a enviar:\n"
         << endl;

    while (tecla != 27)
    {
        // Recibir trama
        char car = recibirCaracter(iface, metadata->type);
        if (car != 0)
        {
            printf("Recibido %c\n", car);
        }

        if (kbhit())
        { // Enviar trama
            tecla = getch();
            if (tecla != 27)
            {
                // Enviamos un carácter
                enviarTrama(iface, &tecla, &metadata);
            }
        }
    }
}

int recibirCadena(interface_t *iface, Metadata *metadata, char cadena[255])
{
    assembled_Packet tramaRecibida = ReceiveFrame(iface);
    int tam = tramaRecibida.header.len - 14; // tamaño del paquete :  macsrc(6), macdst(6), type(2), datos(resto)

    const unsigned char *data = tramaRecibida.packet; // paquete de X tamaño

    if (data)
    {
        if (tam > 0)
        {
            if (data[12] == metadata->type[0] && data[13] == 0x00)
            {
                printf("Mensaje recibido\n");
                printf("Caracteres recibidos: %i\n", tam);

                memcpy(cadena, data + 14, tam);
                cadena[tam] = '\0';
                int ncars = tam;
                return ncars;
            }
        }
    }
    return 0;
}

unsigned char calculoBCE(char cad[255])
{
    unsigned char bce = cad[0];

    for (int i = 1; i < strlen(cad); i++)
    {
        bce = bce ^ cad[i];
    }

    if (bce == 0 || bce == 255)
    {
        bce = 1;
    }

    return bce;
}

void borrarFichero()
{
    ofstream fichero("RProtoc.txt", ios::out | ios::trunc);
    if (fichero.is_open())
    {
        fichero.close();
    }
}

void seleccion(int n, interface_t *iface, Metadata *metadata, int &error)
{
    bool salir = false;
    int tecla;
    int tec;
    char cadena[255];
    int num = 0;

        printf("Selección de modo:\n"
               "[F1] - Envio de caracter interactivo\n"
               if (n == 1) {"[F2] - Envio de un fichero\n"} // esta opcion solo sale si eres el maestro
               "[F3] - Protocolo de para y espera - Seleccion \n"
               "[ESC] - Salir\n");
            // al pulsar F4 en el paro
   
    

    while (!salir)
    {
        if (n == 2)
        {
            if (recibirCadena(iface, &metadata, cadena) != 0)
            {
                cout << cadena << endl;
                num = 1;
            }
            else if (num == 1 && recibirCadena(iface, &metadata, cadena) == 0)
            {
                num = 0;
                printf("\n");
                seleccion(n, iface, &metadata, error);
            }
        }

        if (kbhit())
        {
            tecla = getch();
            if (tecla != 27)
            {
            }
            else
            {
                if (kbhit())
                {
                    tec = getch();
                    if (tec == 'O')
                    {
                        int t = getch();
                        switch (t)
                        {
                        case 'P':
                            envioCaracteresInteractivo(iface, &metadata);
                            if (n == 1)
                            {
                                seleccion(n, iface, &metadata, error);
                            }
                            else if (n == 2)
                            {
                                seleccion(n, iface, &metadata, error);
                            }
                            break;
                        case 'Q':
                            if (n == 1)
                            {
                                envioDeFichero(iface, &metadata);
                                seleccion(n, iface, &metadata, error);
                            }
                            break;
                        case 'R':
                            cout << endl;
                            printf("Protocolo paro y espera\n");
                            if (n == 1)
                            {
                                printf("Estas en modo maestro\n");
                                establecimientoMaestro(iface, &metadata);
                                transferenciaMaestro(iface, &metadata, error);
                                liberacionMaestro(iface, &metadata);
                                printf("Fin de Seleccion por parte del maestro\n");
                                seleccion(n, iface, &metadata, error);
                            }
                            else
                            {
                                printf("Estas en modo esclavo\n");
                                paroYEsperaEsclavo(iface, &metadata);
                                printf("Fin de Seleccion por parte del esclavo\n");
                                seleccion(n, iface, &metadata, error);
                            }
                            break;
                        }
                    }
                }
                else
                {
                    salir = true;
                }
            }
        }
    }
}
