#include "maestro.hpp"

using namespace std;

void pdMaestro(interface_t *iface, int g, int n,Metadata *metadata)
{
    
    metadata->mac_dst = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}; // MAC BROADCAST

    

    //unsigned char type[2];
    metadata->type[0] = 0x30 + g; // cambia con el grupo
    metadata->type[1] = 0x01;

    unsigned char *tramaDescubrimiento = BuildHeader(metadata->mac_src, metadata->mac_dst, metadata->type);

    // PRIMERO MANDAMOS LA TRAMA AL BROADCAST PARA QUE LA RECIBA EL ESCLAVO
    SendFrame(iface, tramaDescubrimiento, 0);
    free(tramaDescubrimiento);

    assembled_Packet trama;

    printf("Esperando que se una la estación esclava\n");

    // EL ESCLAVO NOS HA MANDADO LOS DATOS Y DESCUBRIMOS NUESTRA MAC DESTINO
    bool salir = false;
    while (!salir)
    { // como pongo aqui que mientras que la trama no sea la que le ha enviado el esclavo o nose
        trama = ReceiveFrame(iface);
        if (trama.packet)
        {
            if (trama.packet[12] == metadata->type[0] && trama.packet[13] == 0x02)
            {
                for (int i = 0; i < 6; i++)
                {
                    metadata->mac_dst[i] = trama.packet[i + 6];
                }

                printf("Estación encontrada\n");
                mostrarMACDestino(&metadata);
                salir = true;
            }
        }
    }

    metadata->type[1] = 0x00;
    int error = 0;
    seleccion(n, iface, &metadata, error);
}

void envioDeFichero(interface_t *iface, Metadata *metadata)
{
    int max = 254;
    char cadena[255];

    ifstream fichero("envio.txt", ios::in);

    if (!fichero.is_open())
    {
        cerr << "Error al abrir el fichero" << endl;
    }
    else
    {
        printf("Fichero abierto correctamente\n");
        while (!fichero.eof())
        {
            fichero.read(cadena, 254);
            cadena[fichero.gcount()] = '\0';
            if (fichero.gcount() > 0)
            {
                unsigned char *trama = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, (unsigned char *)cadena);
                SendFrame(iface, trama, fichero.gcount());
            }
        }
        fichero.close();
        printf("Fichero cerrado correctamente\n");
    }
}

void establecimientoMaestro(interface_t *iface, Metadata *metadata)
{
    // el maestro manda trama de control y espera a recibir una trama del esclavo una vez que la reciba manda la de datos

    unsigned char datos[3];
    datos[0] = 'R';
    datos[1] = 05;
    datos[2] = '0';

    unsigned char *tramaEstablecimiento = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, datos); // construimos trama de control ???

    bool end = false;
    SendFrame(iface, tramaEstablecimiento, 3); // mandamos trama de control a destino
    free(tramaEstablecimiento);
    printf("E   %c   ENQ   %c\n", datos[0], datos[2]);
    // esperamos a que la esclava nos responda que esta lista
    while (!end)
    {
        assembled_Packet trama = ReceiveFrame(iface);
        const unsigned char *data = trama.packet;
        if (data)
        { // mientras recibimos
            if (trama.packet[14] == 'R' && trama.packet[15] == 06 && trama.packet[16] == '0')
            {
                printf("R   R   ACK   0 \n");
                printf("\n");
                end = true;
            }
        }
    }
}

void transferenciaMaestro(interface_t *iface, Metadata *metadata, int &error)
{ // tenemos que recibir lo que queremos enviar y en que ciclo estamos, esto solo sirve para enviar y recibir una vez
    // enviamos datos y esperamos que el esclavo nos responda, hasta entonces no podemos enviar nada mas,
    // cuandonos responda si no hay error mandamos mas datos y volvemos a esperar, si el esclavo nos dice que
    // hay error tenemos que volver a mandar la misma trama
    bool end = false;
    char numTrama = '0';
    bool fin = false; // mide cuando termianamos de leer todo el fichero
    // AQUI DEBEMOS REPLICAR EL ENVIARFICHERO PARA ENVIAR LAS TRAMAS
    while (!fin)
    {
        char cad[255];
        ficheroTransfer(cad, fin); // devuelve la cadena
        int longitud = strlen(cad);
        unsigned char bce = calculoBCE(cad);

        unsigned char vectorControl[longitud + 5];
        vectorControl[0] = 'R';      // direccion
        vectorControl[1] = 02;       // tipo de trama
        vectorControl[2] = numTrama; // numero de trama
        vectorControl[3] = longitud; // num de caracteres a enviar

        for (int i = 0; i < longitud; i++)
        {
            vectorControl[i + 4] = cad[i];
        }
        vectorControl[4 + longitud] = bce;

        int tam = longitud + 5;

        unsigned char *tramaControlTransfer = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, vectorControl);

        if (error == 0)
        {
            SendFrame(iface, tramaControlTransfer, tam);
            free(tramaControlTransfer);
            printf("E   %c   STX   %c   %u\n", vectorControl[0], vectorControl[2], vectorControl[4 + longitud]);
            end = false;
        }
        else if (0 < error)
        {
            erroresEnDatos(iface, &metadata, cad, numTrama);
            error--;
        }

        // esperamos que nos responda la esclava y depende de lo que nos responda hacemos una cosa u otra
        while (!end)
        {
            assembled_Packet trama = ReceiveFrame(iface);
            const unsigned char *data = trama.packet;
            if (data)
            { // mientras recibimos
                if (trama.packet[14] == 'R' && trama.packet[15] == 06 && trama.packet[16] == vectorControl[2])
                {
                    printf("R   %c   ACK   %c\n", vectorControl[0], vectorControl[2]);
                    end = true;
                    if (numTrama == '0')
                    {
                        numTrama = '1';
                    }
                    else
                    {
                        numTrama = '0';
                    }
                }
                else
                {
                    if (trama.packet[14] == 'R' && trama.packet[15] == 21 && trama.packet[16] == vectorControl[2])
                    {
                        printf("Recibbbb   %c  NACK   %c\n", vectorControl[0], vectorControl[2]);
                        printf("Ennnnvvv   %c   STX   %c   %u\n", vectorControl[0], vectorControl[2], vectorControl[4 + longitud]);
                        unsigned char *tramaControlTransfer = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, vectorControl);
                        SendFrame(iface, tramaControlTransfer, 259);
                        free(tramaControlTransfer);
                        // (retransmite trama)
                    }
                }
            }
        }

        if (kbhit())
        {
            int tecla = getch();
            if (tecla == 27)
            { //
                if (kbhit())
                {
                    int tec = getch();
                    if (tec == 'O')
                    {
                        int t = getch(); // F4 SE CORRESPONDE CON S
                        if (t == 'S')
                        {
                            error++;
                            printf("INTRODUCIENDO ERROR\n");
                        }
                    }
                }
            }
        }
    }
}

void liberacionMaestro(interface_t *iface, Metadata *metadata)
{
    // mandamos trama de liberacion y si el maestro nos la acepta nos salimos de la conversacion
    unsigned char vectorControl[3];
    vectorControl[0] = 'R';
    vectorControl[1] = 04;
    vectorControl[2] = '0';

    unsigned char *tramaControlLiberacion = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, vectorControl);
    SendFrame(iface, tramaControlLiberacion, 3);
    printf("\n");
    printf("E   %c   EOT   %c\n", vectorControl[0], vectorControl[2]);

    bool end = false;
    // esperamos que nos responda la esclava y depende de lo que nos responda hacemos una cosa u otra
    while (!end)
    {
        assembled_Packet trama = ReceiveFrame(iface);
        const unsigned char *data = trama.packet;
        if (data)
        { // mientras recibimos
            if (trama.packet[14] == 'R' && trama.packet[15] == 06 && trama.packet[16] == '0')
            {
                end = true;
                printf("R   %c   ACK   %c\n", vectorControl[0], vectorControl[2]);
            }
        }
    }
}

void ficheroTransfer(char cad[255], bool &end)
{

    static ifstream fichero("EProtoc.txt", ios::in);

    if (!fichero.is_open())
    {
        cad[0] = '\0';
        end = true;
    }
    else
    {

        if (!fichero.eof())
        {
            fichero.read(cad, 254);
            cad[fichero.gcount()] = '\0';
            end = fichero.eof();
        }
        else
        {
            cad[0] = '\0';
            end = true;
            fichero.close();
        }
    }
}

void erroresEnDatos(interface_t *iface, Metadata *metadata, char cad[], char &numTrama)
{
    char car = cad[0]; // guardamos el valor original de la primera posicion para reconstruirla
    unsigned char bce = calculoBCE(cad);

    bool end = false;
    cad[0] = 'ç'; // cambiamos el primer caracter para cambiar el bce del esclavo y que devuelva error

    int longitud = strlen(cad);

    unsigned char vectorDatos[longitud + 5];

    vectorDatos[0] = 'R';
    vectorDatos[1] = 02;
    vectorDatos[2] = numTrama;
    vectorDatos[3] = longitud;

    for (int i = 0; i < longitud; i++)
    {
        vectorDatos[i + 4] = cad[i];
    }
    vectorDatos[4 + longitud] = bce;

    int tam = longitud + 5;

    unsigned char *tramaErronea = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, vectorDatos);
    SendFrame(iface, tramaErronea, tam);
    printf("E   %c   STX   %c   %u\n", vectorDatos[0], vectorDatos[2], bce);
    free(tramaErronea);

    cad[0] = car; // reestablecemos la cadena original

    while (!end)
    {
        assembled_Packet trama = ReceiveFrame(iface);
        const unsigned char *data = trama.packet;
        if (data)
        { // mientras recibimos
            if (trama.packet[14] == 'R' && trama.packet[15] == 06 && trama.packet[16] == vectorDatos[2])
            {
                printf("R   %c   ACK   %c\n", vectorDatos[0], vectorDatos[2]);
                end = true;
                if (numTrama == '0')
                {
                    numTrama = '1';
                }
                else
                {
                    numTrama = '0';
                }
            }
            else
            {
                if (trama.packet[14] == 'R' && trama.packet[15] == 21 && trama.packet[16] == vectorDatos[2])
                {
                    printf("R   %c  NACK   %c\n", vectorDatos[0], vectorDatos[2]);

                    for (int i = 0; i < longitud; i++)
                    {
                        vectorDatos[i + 4] = cad[i];
                    }

                    printf("E   %c   STX   %c   %u\n", vectorDatos[0], vectorDatos[2], vectorDatos[4 + longitud]);
                    unsigned char *tramaControlTransfer = BuildFrame(metadata->mac_src, metadata->mac_dst, metadata->type, vectorDatos);
                    SendFrame(iface, tramaControlTransfer, 259);
                    free(tramaControlTransfer);
                    // (retransmite trama)
                }
            }
        }
    }
}