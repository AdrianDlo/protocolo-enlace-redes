//============================================================================
// ----------- PRACTICAS DE FUNDAMENTOS DE REDES DE COMUNICACIONES -----------
// ---------------------------- CURSO 2025/26 --------------------------------
// ----------------------------- SESION1.CPP ---------------------------------
//============================================================================

/*AUTORES:
Grupo 3
*Adrián de la Osa García
*/
#include <stdio.h>
#include <iostream>
#include "linkLayer.h"
#include <string>
#include <stdio_ext.h>
#include <fstream>

using namespace std;

void mostrarInterfacesDisponibles(pcap_if_t *avail_ifaces)
{
    // recorremos las interfaces para poder mostrarlas todas
    for (int i = 0; avail_ifaces != nullptr; i++)
    {
        cout << "[" << i << "]" << avail_ifaces->name << endl;
        avail_ifaces = avail_ifaces->next;
    }
}

void seleccionarInterfaz(pcap_if_t *avail_ifaces, interface_t *iface)
{
    cout << "Seleccione interfaz: ";
    int n;
    cin >> n;

    // Mostrar nombre de interfaz seleccionada
    for (int j = 1; j <= n; j++)
    {
        avail_ifaces = avail_ifaces->next;
    }
    cout << "Interfaz Elegida :" << avail_ifaces->name << endl;
    setDeviceName(iface, avail_ifaces->name);
    GetMACAdapter(iface);
}

void mostrarMAC(unsigned char v[6])
{
    cout << "La MAC es: ";
    for (int i = 0; i < 6; i++)
    {
        if (i == 5)
        {
            printf("%X", v[i]);
        }
        else if (i < 5)
        {
            printf("%X:", v[i]);
        }
    }
    cout << endl;
}
void enviarTrama(interface_t *iface, char *car, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2])
{
    unsigned char *tramaEnviada = BuildFrame(mac_src, mac_dst, type, (unsigned char *)car);
    SendFrame(iface, tramaEnviada, 1);
    free(tramaEnviada);
}

char recibirCaracter(interface *iface)
{
    // char car;
    assembled_Packet tramaRecibida = ReceiveFrame(iface);
    int tam = tramaRecibida.header.len - 14;          // tamaño del paquete :  macsrc(6), macdst(6), type(2), datos(resto)
    const unsigned char *data = tramaRecibida.packet; // paquete de X tamaño
    if (data)
    {
        printf("Caracteres recibidos: %i\n", tam);
        return data[14];
    }
    return 0;
}

int abrirPuerto(interface_t *iface)
{
    int puerto = OpenAdapter(iface);
    if (puerto != 0)
    {
        printf("Error al abrir el puerto\n");
        getch();
        return (1);
    }
    else
        printf("Puerto abierto correctamente\n");
    return 0;
}

int cerrarPuerto(interface_t *iface)
{
    CloseAdapter(iface);
    printf("Puerto cerrado\n");
    return 0;
}

void envioCaracteresInteractivo(interface_t *iface)
{
    unsigned char mac_src[6] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    unsigned char mac_dst[6] = {0x08, 0x00, 0x27, 0xE7, 0xBD, 0x13}; // MAC DEL COMPAÑERO
    unsigned char type[2] = {0x30, 0x00};
    // seleccionarModoEstacion();
    char tecla = 0;
    __fpurge(stdin);
    cout << "Pulse los caracteres a enviar:\n"
         << endl;

    while (tecla != 27)
    {
        // Recibir trama
        char car = recibirCaracter(iface);
        if (car != 0)
        {
            printf("Recibido %c\n", car);
        }

        if (kbhit())
        { // Enviar trama
            tecla = getch();
            if (tecla != 27)
            {
                // Enviamos un carácter
                enviarTrama(iface, &tecla, mac_src, mac_dst, type);
            }
        }
    }
    cout<<"saliiendoo"<<endl;
}

// SOLO PARA EL MAESTRO
void envioDeFichero(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2])
{
    int max = 254;
    char cadena[255];

    ifstream fichero("envio.txt", ios::in);

    if (!fichero.is_open())
    {
        cerr << "Error al abrir el fichero" << endl;
    }
    else
    {
        printf("Fichero abierto correctamente\n");
        while (!fichero.eof())
        {
            fichero.read(cadena, 254);
            cadena[fichero.gcount()] = '\0';
            if (fichero.gcount() > 0)
            {
                unsigned char *trama = BuildFrame(mac_src, mac_dst, type, (unsigned char *)cadena);
                SendFrame(iface, trama, fichero.gcount());
            }
        }
        fichero.close();
        printf("Fichero cerrado correctamente\n");
    }
}

// ¿BIEN?
int recibirCadena(interface *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2], char cadena[255])
{
    apacket_t tramaRecibida = ReceiveFrame(iface);
    if(tramaRecibida.packet == NULL){
        return 0;
    }
    int tam = tramaRecibida.header.len - 14; // tamaño del paquete :  macsrc(6), macdst(6), type(2), datos(resto)
    
    const unsigned char *data = tramaRecibida.packet; // paquete de X tamaño

    if (data)
    {
        if (tam > 0)
        {
            if (data[12] == type[0] && data[13] == 0x00)
            {
                printf("Caracteres recibidos: %i\n", tam);

                memcpy(cadena, data + 14, tam);
                cadena[tam] = '\0';
                int ncars = tam;
                return ncars;
            }
        }
    }
    return 0;
}

// MISMO MODULO PARA ESCLAVO Y MAESTRO
void seleccion(int n, interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2])
{
    bool salir = false;
    char tecla;
    int tec;
    char cadena[255];

    if (n == 1)
    {
        printf("Selección de modo:\n"
               "[F1] - Envio de caracter interactivo\n"
               "[F2] - Envio de un fichero\n"
               "[ESC] - Salir\n");
    }
    else if (n == 2)
    {
        printf("Selección de modo:\n"
               "[F1] - Envio de caracter interactivo\n"
               "[ESC] - Salir\n");
    }

    while (!salir)
    {
        if (n == 2)
        {
            if (recibirCadena(iface, mac_src, mac_dst, type, cadena) != 0)
            {
                printf("Mensaje recibido\n");
                printf(cadena);
            }
        }

        if (kbhit())
        {
            int c1 = getch(); // ESC
            if (c1 == 27)
            {
                int c2 = getch(); // 'O'
                if (c2 == 'O')
                {
                    int c3 = getch(); // 'P', 'Q', 'R', 'S'
                    switch (c3)
                    {
                    case 'P': // F1
                        envioCaracteresInteractivo(iface);
                        break;

                    case 'Q': // F2
                        if (n == 1)
                        {
                            envioDeFichero(iface, mac_src, mac_dst, type);
                        }
                        break;

                    case 'R': // F3
                        printf("F3 pulsada\n");
                        break;

                    case 'S': // F4
                        printf("F4 pulsada\n");
                        break;
                    }
                }
            }
        }
    }
}

// PROTOCOLO DESCUBRIMIENTO
void pdMaestro(interface_t *iface, int g, int n)
{
    unsigned char mac_src[6];
    unsigned char mac_dst[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}; // MAC BROADCAST

    for (int i = 0; i < 6; i++)
    {
        mac_src[i] = iface->MACaddr[i];
    }

    unsigned char type[2];
    type[0] = 0x30 + g; // cambia con el grupo
    type[1] = 0x01;

    unsigned char *tramaDescubrimiento = BuildHeader(mac_src, mac_dst, type);

    // PRIMERO MANDAMOS LA TRAMA AL BROADCAST PARA QUE LA RECIBA EL ESCLAVO
    SendFrame(iface, tramaDescubrimiento, 0);
    // free(tramaDescubrimiento);

    assembled_Packet trama;

    printf("Esperando que se una la estación esclava\n");

    // EL ESCLAVO NOS HA MANDADO LOS DATOS Y DESCUBRIMOS NUESTRA MAC DESTINO
    bool salir = false;
    while (!salir)
    { // como pongo aqui que mientras que la trama no sea la que le ha enviado el esclavo o nose
        trama = ReceiveFrame(iface);
        if (trama.packet)
        {
            if (trama.packet[12] == type[0] && trama.packet[13] == 0x02)
            {
                for (int i = 0; i < 6; i++)
                {
                    mac_dst[i] = trama.packet[i + 6];
                }

                printf("Estación encontrada\n");
                mostrarMAC(mac_dst);
                salir = true;
            }
        }
    }

    type[1] = 0x00;

    seleccion(n, iface, mac_src, mac_dst, type);
}

void pdEsclavo(interface_t *iface, int g, int n)
{
    unsigned char mac_src[6] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; // MAC PROPIA
    unsigned char mac_dst[6] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; // MAC maestro  que se actualiza despues
    unsigned char type[2];                                           // TIPO DEL PROTOCOLO MODIFICADO (CAMBIAR EL PRIMERO)

    type[0] = 0x30 + g; // cambia con el grupo
    type[1] = 0x02;

    for (int i = 0; i < 6; i++)
    {
        mac_src[i] = iface->MACaddr[i];
    }

    printf("Esperando que se una la estación maestra\n");

    // RECIBIMOS LA TRAMA DEL BROADCAST Y FILTRAMOS PARA TENER LA QUE QUERAMOS

    bool end = false;

    while (!end)
    {
        assembled_Packet trama = ReceiveFrame(iface);
        const unsigned char *data = trama.packet;
        if (data)
        { // mientras recibimos
            if (trama.packet[12] == type[0] && trama.packet[13] == 0x01)
            {
                for (int i = 0; i < 6; i++)
                {
                    mac_dst[i] = trama.packet[i + 6];
                }
                printf("Estación encontrada\n");
                mostrarMAC(mac_dst);
                end = true;
            }
        }
    }

    // UNA VEZ ENCONTRADA MANDAMOS UN MENSAJE A ESA DIRECCION PARA QUE NOS DESCUBRA
    unsigned char *tramaDescubrimiento = BuildHeader(mac_src, mac_dst, type);
    SendFrame(iface, tramaDescubrimiento, 0);

    type[1] = 0x00;

    seleccion(n, iface, mac_src, mac_dst, type);
}

int seleccionarGrupo()
{
    printf("Introduzca el numero de grupo:\n");
    int grupo;
    cin >> grupo;
    return grupo;
}

void seleccionarModo(interface_t *iface, int g)
{
    int n;
    printf("Selección el modo de la estación\n");
    printf("[1] Modo Maestro\n");
    printf("[2] Modo Esclavo\n");
    cin >> n; // modo
    if (n != 27)
    {
        if (n == 1)
        {
            pdMaestro(iface, g, n);
        }
        else if (n == 2)
        {
            pdEsclavo(iface, g, n);
        }
    }
}

int main()
{
    interface_t iface;
    pcap_if_t *avail_ifaces = NULL;

    avail_ifaces = GetAvailAdapters();

    mostrarInterfacesDisponibles(avail_ifaces);
    seleccionarInterfaz(avail_ifaces, &iface);
    mostrarMAC(iface.MACaddr);

    // SELECCIONAMOS EL GRUPO QUE QUERAMOS
    int g = seleccionarGrupo();
    // ABRIMOS EL PUERTO PARA PODER COMUNICARNOS
    abrirPuerto(&iface);
    // SELECCIONAMOS EL MODO DE LA ESTACION
    seleccionarModo(&iface, g);
    // HEMOS TERMINADO -->CERRAMOS EL PUERTO
    cerrarPuerto(&iface);

    // FIN DE DESCUBRIMIENTO TIPO[2] TIENE QUE SER 0

    // HACER LIBRERIAS .H/.CPP
    // RECIBIR FICHERO RECIBE LAS TRAMAS DESORDENADAS (ES ASI EN UNA RED, EN EL SCRIPT NO) (DEJARLO ASI)

    return 0;
}