//============================================================================
// ----------- PRACTICAS DE FUNDAMENTOS DE REDES DE COMUNICACIONES -----------
// ---------------------------- CURSO 2025/26 --------------------------------
// ----------------------------- SESION1.CPP ---------------------------------
//============================================================================


/*AUTORES:
*Javier Montero Pajuelo - Grupo 3
*Adrián de la Osa García
*/
#include <stdio.h>
#include <iostream>
#include "linkLayer.h"
#include <string>
#include <stdio_ext.h>

using namespace std;

void mostrarInterfacesDisponibles(pcap_if_t *avail_ifaces){
    //recorremos las interfaces para poder mostrarlas todas
    for(int i=0;avail_ifaces!=nullptr;i++){
        cout << "[" << i << "]" << avail_ifaces->name << endl;
        avail_ifaces=avail_ifaces->next;
    }
}

void seleccionarInterfaz(pcap_if_t *avail_ifaces, interface_t *iface){
    cout<< "Seleccione interfaz: ";
    int n;
    cin >> n;

    //Mostrar nombre de interfaz seleccionada
    for(int j=1;j<=n;j++){ 
        avail_ifaces=avail_ifaces->next;
    }
    cout<< "Interfaz Elegida :" << avail_ifaces->name<< endl; 
    setDeviceName(iface, avail_ifaces->name);
}
    

void mostrarMACOrigen(interface_t *iface){
    //Mostrar MAC de la interfaz selccionada
    GetMACAdapter(iface);
    cout<<"La MAC origen es: ";
    for(int i=0;i<6;i++){
        if(i==5){
            printf("%XX", iface->MACaddr[i]);
        }
        else if (i<5){
            printf("%X:", iface->MACaddr[i]);
        }
    }
    cout<<endl;
}

void mostrarMACDestino(interface_t *iface){
    //Mostrar MAC de la interfaz selccionada
    GetMACAdapter(iface);
    cout<<"La MAC destino es: ";
    for(int i=0;i<6;i++){
        if(i==5){
            printf("%X", iface->MACaddr[i]);
        }
        else if (i<5){
            printf("%X:", iface->MACaddr[i]);
        }
    }
    cout<<endl;
}

void enviarTrama(interface_t *iface, char *car, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]){
unsigned char * tramaEnviada = BuildFrame(mac_src, mac_dst, type, (unsigned char*)car);
SendFrame(iface, tramaEnviada, 1);
free(tramaEnviada);
}

char recibirCaracter(interface *iface){
    //char car;
    assembled_Packet tramaRecibida =  ReceiveFrame(iface);
    int tam = tramaRecibida.header.len - 14; //tamaño del paquete :  macsrc(6), macdst(6), type(2), datos(resto)
    const unsigned char* data = tramaRecibida.packet; //paquete de X tamaño
    if(data){
        printf("Caracteres recibidos: %i\n", tam);
        return data[14];
    }
    return 0;
}



int mensajear(interface_t iface){
    unsigned char mac_src[6]={0x00, 0x00, 0x00, 0x00,0x00, 0x00}; //MAC ORIGEN
    unsigned char mac_dst[6]={0x08, 0x00, 0x27, 0xE7,0xBD, 0x13}; //MAC DESTINO
    unsigned char type[2]={0x30,0x00};

    int puerto = OpenAdapter(&iface);
    if(puerto != 0)
        {
            printf("Error al abrir el puerto\n");
            getch();
            return (1);
        }
    else
        printf("Puerto abierto correctamente\n");


    char tecla;
    __fpurge(stdin);
    cout<<"Pulse los caracteres a enviar:"<<endl;

    while(tecla!=27){
        //Recibir trama
     char car = recibirCaracter(&iface);
        if(car!=0){
            printf("Recibido %c\n", car);
        }
        
        if(kbhit()){ //Enviar trama
            tecla=getch();
            if(tecla!=27){
                //Enviamos un carácter
                enviarTrama(&iface,&tecla,mac_src,mac_dst,type);
            }
        }
      
    }
  //Cerramos el puerto:
  CloseAdapter(&iface);
  printf("Puerto cerrado\n");
  return 0;

}


int main()
{
 interface_t iface;
 pcap_if_t *avail_ifaces=NULL;
 
 printf("\n----------------------------\n");
 printf("------ SESION 2 - FRC ------\n");
 printf("----------------------------\n");
    
avail_ifaces=GetAvailAdapters(); 

//SESION 1
mostrarInterfacesDisponibles(avail_ifaces);
seleccionarInterfaz(avail_ifaces, &iface);
mostrarMACOrigen(&iface);
mostrarMACDestino(&iface);

//SESION 2
mensajear(iface);
}
