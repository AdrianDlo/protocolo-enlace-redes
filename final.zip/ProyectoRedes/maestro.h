#include <stdio.h>
#include <iostream>
#include "linkLayer.h"
#include <string>
#include <stdio_ext.h>
#include <fstream>
#include "comunes.h"

#ifndef MAESTRO_H
#define MAESTRO_H


//PROTOCOLO DE DESCUBRIMIENTO MAESTRO
void pdMaestro(interface_t *iface, int g, int n);
//ENVIAR TRAMAS CON EL CONTENIDO DEL FICHERO (F2)
void envioDeFichero(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]);
//FASE DE ESTABLECIMIENTO PARO Y ESPERA
void establecimientoMaestro(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]);
//FASE DE TRANSFERENCIA PARO Y ESPERA
void transferenciaMaestro(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2], int &error);
//FASE DE LIBERACION PARO Y ESPERA
void liberacionMaestro(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]);
//COPIA EL CONTENIDO DEL FICHERO EN UNA CADENA
void ficheroTransfer(char cad[255], bool &end);
//INTRODUCE LOS ERRORES EN LOS DATOS
void erroresEnDatos(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2],  char cad[], char &numTrama);

#endif