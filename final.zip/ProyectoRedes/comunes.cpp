#include "comunes.h"

using namespace std;


int abrirPuerto(interface_t *iface){
    int puerto = OpenAdapter(iface);
    if(puerto != 0)
        {
            printf("Error al abrir el puerto\n");
            getch();
            return (1);
        }
    else
        printf("Puerto abierto correctamente\n");
        return 0;
}

int cerrarPuerto(interface_t *iface){
    CloseAdapter(iface);
    printf("Puerto cerrado\n");
    return 0;
}

void mostrarInterfacesDisponibles(pcap_if_t *avail_ifaces){
    //recorremos las interfaces para poder mostrarlas todas
    for(int i=0;avail_ifaces!=nullptr;i++){
        cout << "[" << i << "]" << avail_ifaces->name << endl;
        avail_ifaces=avail_ifaces->next;
    }
}

void seleccionarInterfaz(pcap_if_t *avail_ifaces, interface_t *iface){
    cout<< "Seleccione interfaz: ";
    int n;
    cin >> n;

    //Mostrar nombre de interfaz seleccionada
    for(int j=1;j<=n;j++){ 
        avail_ifaces=avail_ifaces->next;
    }
    cout<< "Interfaz Elegida :" << avail_ifaces->name<< endl; 
    setDeviceName(iface, avail_ifaces->name);
    GetMACAdapter(iface);
}

void mostrarMAC(unsigned char  v[6]){
    cout<<"La MAC es: ";
       for(int i=0;i<6;i++){
           if(i==5){
               printf("%X", v[i]);
           }
           else if (i<5){
               printf("%X:", v[i]);
           }
       }
       cout<<endl;
   
   
   }

int seleccionarGrupo() {
    printf("Introduzca el numero de grupo:\n");
    int grupo;
    cin>>grupo;
    return grupo;
}

void seleccionarModo(interface_t *iface, int g){
    int n; 
    char numTrama='0';
    printf("Selección el modo de la estación\n");
    printf("[1] Modo Maestro\n");
    printf("[2] Modo Esclavo\n");
    cin>>n; //modo
    if(n!=27){
        if(n==1){
            pdMaestro(iface,g, n);
            
        }
        else if (n==2){
            pdEsclavo(iface, g, n);
        }   
    }
}
   void enviarTrama(interface_t *iface, char *car, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]){
   unsigned char * tramaEnviada = BuildFrame(mac_src, mac_dst, type, (unsigned char*)car);
   SendFrame(iface, tramaEnviada, 1);
   free(tramaEnviada);
   }


char recibirCaracter(interface_t *iface,unsigned char type[2]){
    //char car;
    assembled_Packet tramaRecibida =  ReceiveFrame(iface);
    int tam = tramaRecibida.header.len - 14; //tamaño del paquete :  macsrc(6), macdst(6), type(2), datos(resto)
    const unsigned char* data = tramaRecibida.packet; //paquete de X tamaño
    if(data){
         if(data[12]==type[0] && data[13]==0x00){
            printf("Caracteres recibidos: %i\n", tam);
            return data[14];
        }
    }
    return 0;
}


void envioCaracteresInteractivo(interface_t *iface,unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]){
    char tecla;
    __fpurge(stdin);
    cout<<"Pulse los caracteres a enviar:\n"<<endl;

    while(tecla!=27){
        //Recibir trama
     char car = recibirCaracter(iface, type);
        if(car!=0){
            printf("Recibido %c\n", car);
        }
        
        if(kbhit()){ //Enviar trama
            tecla=getch();
            if(tecla!=27){
                //Enviamos un carácter
                enviarTrama(iface,&tecla,mac_src,mac_dst,type);
            }
        }
      
    }
}



int recibirCadena(interface_t *iface,
                  unsigned char mac_src[6],
                  unsigned char mac_dst[6],
                  unsigned char type[2],
                  char cadena[255])
{
    assembled_Packet tramaRecibida = ReceiveFrame(iface);
    const unsigned char* data = tramaRecibida.packet;

    if(!data)
        return 0;

    // Solo tramas del protocolo de datos
    if(data[12] != type[0] || data[13] != 0x00)
        return 0;

    int tam = tramaRecibida.header.len - 14;
    if(tam <= 0)
        return 0;

    memcpy(cadena, data + 14, tam);
    cadena[tam] = '\0';

    return tam;
}



unsigned char calculoBCE(char cad[255]){
    unsigned char bce = cad[0];
    
    for(int i = 1; i < strlen(cad); i++){
        bce = bce ^ cad[i];
    }

    if(bce==0 || bce==255){
        bce = 1;
    }

    return bce;

}

void borrarFichero() {
    ofstream fichero("RProtoc.txt", ios::out | ios::trunc);
    if (fichero.is_open()) {
        fichero.close();
    }
}

void seleccion(int n, interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2], int &error){
    bool salir = false;
    int tecla;
    int tec;
    char cadena [255];
    int num=0;

    if(n==1){
        printf("Selección de modo:\n"
        "[F1] - Envio de caracter interactivo\n"
        "[F2] - Envio de un fichero\n"
        "[F3] - Protocolo de para y espera - Seleccion \n"
        "[F4] - Introduccion errores durante protocolo \n"
        "[ESC] - Salir\n");
    }else if(n==2){
        printf("Selección de modo:\n"
        "[F1] - Envio de caracter interactivo\n"
        "[F3] - Protocolo de para y espera - Seleccion\n"
        "[ESC] - Salir\n");
    }

    
while(!salir){

    

if(n == 2){
    static int numTrama = 1;

    int ncars = recibirCadena(iface, mac_src, mac_dst, type, cadena);
    if(ncars > 0){
        printf("Recibido %s\n", cadena);
        printf("Nº caracteres recibidos: %d\n\n", ncars);
        numTrama++;
  
    }
}
    


    if(kbhit()){
        int tecla = getch();

        // ✅ ESC → salir del programa
        if(tecla == 27){
            printf("Saliendo del programa...\n");
            salir = true;
        }

        // ✅ Teclas especiales (F1, F2, F3, F4)
        else if(tecla == 0 || tecla == 224){
            int t = getch();

            switch(t){

                case 59: // F1
                    envioCaracteresInteractivo(iface, mac_src, mac_dst, type);
                    break;

                case 60: // F2
                    if(n == 1){
                        envioDeFichero(iface, mac_src, mac_dst, type);
                    }
                    break;

                case 61: // F3
                    printf("Protocolo paro y espera\n");
                    if(n == 1){
                        establecimientoMaestro(iface, mac_src, mac_dst, type);
                        transferenciaMaestro(iface, mac_src, mac_dst, type, error);
                        liberacionMaestro(iface, mac_src, mac_dst, type);
                    } else {
                        paroYEsperaEsclavo(iface, mac_src, mac_dst, type);
                    }
                    break;

                case 62: // F4
                    error++;
                    printf("Introduciendo error\n");
                    break;
            }
        }
    }
}
   
}

