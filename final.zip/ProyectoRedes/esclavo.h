#include <stdio.h>
#include <iostream>
#include "linkLayer.h"
#include <string>
#include <stdio_ext.h>
#include <fstream>
#include "comunes.h"

using namespace std;


#ifndef ESCLAVO_H
#define ESCLAVO_H

//PROTOCOLO DE DESCUBRIMIENTO DEL ESCLAVO
void pdEsclavo(interface_t *iface, int g, int n);
//PROTOCOLO COMPLETO DE PARO Y ESPERA DEL ESCLAVO
void paroYEsperaEsclavo(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]);
//ESCIRIBIR LAS TRAMAS RECIBIDAS CORRECTAMENTE EN EL FICHERO "RPROTOC.TXT"
void escribirFichero(string &nombre,  char datos[]);


#endif