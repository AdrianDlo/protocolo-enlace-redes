#include <stdio.h>
#include <iostream>
#include "linkLayer.h"
#include <string>
#include <stdio_ext.h>
#include <fstream>


#ifndef COMUNES_H
#define COMUNES_H


//ABRE EL PUERTO PARA PERMITIR LA COMUNICACION
int abrirPuerto(interface_t *iface);
//CIERRA EL PUERTO PARA TERMINAR LA COMUNICACION
int cerrarPuerto(interface_t *iface);
//MUESTRA LAS INTERFACES DISPONIBLES
void mostrarInterfacesDisponibles(pcap_if_t *avail_ifaces);
//SELECCIONA LA INTERFAZ ELEGIDA
void seleccionarInterfaz(pcap_if_t *avail_ifaces, interface_t *iface);
//MUESTRA LA DIRECCION MAC DE LA INTERFAZ ELEGIDA
void mostrarMAC(unsigned char  v[6]);
//SELECCIONA EL GRUPO ELEGIDO
int seleccionarGrupo();
//SELECCIONA ENTRE MODO MAESTRO/ESCLAVO
void seleccionarModo(interface_t *iface, int g);
//ENVIA UNA TRAMA DE DATOS
void enviarTrama(interface_t *iface, char *car, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]);
//RECIBE UN CARACTER DE OTRA INTEFAZ
char recibirCaracter(interface_t *iface,unsigned char type[2]);
//ENVIO DE CARACTERES INTERACTIVOS (CHAT) ENTRE MAESTRO Y ESCLAVO
void envioCaracteresInteractivo(interface_t *iface,unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]);
//RECIBE UNA CADENA COMPLETA
int recibirCadena(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2], char cadena[255]);
//CALCULA EL BCE 
unsigned char calculoBCE(char cad[255]);
//BORRA EL CONTENIDO PREVIO DEL FICHERO "RPROTOC.TXT"
void borrarFichero();
//MENU DE SELECCION DE OPCIONES DE MAESTRO/ESCLAVO
void seleccion(int n, interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2], int &error);


//DECLARACION DE CABECERAS PARA USAR METODOS DE ESCLAVO Y MAESTRO
//ESTO ES DEBIDO A QUE NO PODEMOS HACER INCLUDE PUESTO Q HABRIA INCLUDES CICLICOS Y SALTA EL ERROR: "MAESTRO.H SE INLCUYE A SI MISMO"//"ESCLAVO.H SE INCLUYE A SI MISMO"
//MAESTRO
void envioDeFichero(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]);
void establecimientoMaestro(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]);
void transferenciaMaestro(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2], int &error);
void liberacionMaestro(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]);
void pdMaestro(interface_t *iface, int g, int n);

//ESCLAVO
void pdEsclavo(interface_t *iface, int g, int n);
void paroYEsperaEsclavo(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]);


#endif