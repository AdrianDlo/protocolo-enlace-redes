//============================================================================
// ----------- PRACTICAS DE FUNDAMENTOS DE REDES DE COMUNICACIONES -----------
// ---------------------------- CURSO 2025/26 --------------------------------
// ----------------------------- SESION1.CPP ---------------------------------
//============================================================================

/*AUTORES:
Grupo 3
*Adrián de la Osa García
Sergio Sánchez Amado
*/
#include <stdio.h>
#include <iostream>
#include "linkLayer.h"
#include <string>
#include <stdio_ext.h>
#include <fstream>

#include "comunes.h"

using namespace std;

int main()
{
    
 interface_t iface;
 pcap_if_t *avail_ifaces=NULL;
 
    
avail_ifaces=GetAvailAdapters(); 


mostrarInterfacesDisponibles(avail_ifaces);
seleccionarInterfaz(avail_ifaces, &iface);
mostrarMAC(iface.MACaddr);

//SELECCIONAMOS EL GRUPO QUE QUERAMOS
int g= seleccionarGrupo();
//ABRIMOS EL PUERTO PARA PODER COMUNICARNOS
abrirPuerto(&iface);
//BORRAMOS EL CONTENIDO PREVIO DE RPROTOC
borrarFichero();
//SELECCIONAMOS EL MODO DE LA ESTACION
seleccionarModo(&iface, g);
//HEMOS TERMINADO -->CERRAMOS EL PUERTO
cerrarPuerto(&iface);


 //FIN DE DESCUBRIMIENTO TIPO[2] TIENE QUE SER 0

//HACER LIBRERIAS .H/.CPP
//RECIBIR FICHERO RECIBE LAS TRAMAS DESORDENADAS (ES ASI EN UNA RED, EN EL SCRIPT NO) (DEJARLO ASI)

return 0;
}