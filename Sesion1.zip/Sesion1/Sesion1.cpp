//============================================================================
// ----------- PRACTICAS DE FUNDAMENTOS DE REDES DE COMUNICACIONES -----------
// ---------------------------- CURSO 2025/26 --------------------------------
// ----------------------------- SESION1.CPP ---------------------------------
//============================================================================


#include <stdio.h>
#include <iostream>
#include "linkLayer.h"
#include <string>
#include <stdio_ext.h>
using namespace std;

void mostrarInterfacesDisponibles(pcap_if_t *avail_ifaces){
    for(int i=0; avail_ifaces!=nullptr;i++){
        cout<<"["<<i<<"]"<< avail_ifaces->name<<endl;
        avail_ifaces=avail_ifaces->next;
    }   
}


void selecionarInterfaz(pcap_if_t *avail_ifaces, interface_t *iface){
    cout<<"Selecione interfaz ";
    int n;
    cin>>n;
    
    for(int j=1;j<=n;j++){
        avail_ifaces=avail_ifaces->next;
    }
    
    cout<<"Interfaz elegida :"<<avail_ifaces->name<<endl;
    setDeviceName(iface, avail_ifaces->name);
}

void mostrarMac(interface_t iface){
    GetMACAdapter(&iface);
    char mac[18];
    snprintf(mac, sizeof(mac), "%02X:%02X:%02X:%02X:%02X:%02X", iface.MACaddr[0],iface.MACaddr[1],iface.MACaddr[2],iface.MACaddr[3],iface.MACaddr[4],iface.MACaddr[5]);
    cout<<"La MAC es: "<<mac<<endl;
}
int main()
{
 interface_t iface;
 pcap_if_t *avail_ifaces=NULL;
 
 printf("\n----------------------------\n");
 printf("------ SESION 1 - FRC ------\n");
 printf("----------------------------\n");
    
 avail_ifaces=GetAvailAdapters(); 

 //setDeviceName(&iface, "lo");
 //GetMACAdapter(&iface);
 //PrintMACAdapter(&iface); 



mostrarInterfacesDisponibles(avail_ifaces);
selecionarInterfaz(avail_ifaces, &iface);
mostrarMac(iface);

 return 0;
}
