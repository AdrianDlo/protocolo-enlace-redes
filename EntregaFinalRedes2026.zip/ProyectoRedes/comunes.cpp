#include "comunes.h"

using namespace std;


int abrirPuerto(interface_t *iface){
    int puerto = OpenAdapter(iface);
    if(puerto != 0)
        {
            printf("Error al abrir el puerto\n");
            getch();
            return (1);
        }
    else
        printf("Puerto abierto correctamente\n");
        return 0;
}

int cerrarPuerto(interface_t *iface){
    CloseAdapter(iface);
    printf("Puerto cerrado\n");
    return 0;
}

void mostrarInterfacesDisponibles(pcap_if_t *avail_ifaces){
    //recorremos las interfaces para poder mostrarlas todas
    for(int i=0;avail_ifaces!=nullptr;i++){
        cout << "[" << i << "]" << avail_ifaces->name << endl;
        avail_ifaces=avail_ifaces->next;
    }
}

void seleccionarInterfaz(pcap_if_t *avail_ifaces, interface_t *iface){
    cout<< "Seleccione interfaz: ";
    int n;
    cin >> n;

    //Mostrar nombre de interfaz seleccionada
    for(int j=1;j<=n;j++){ 
        avail_ifaces=avail_ifaces->next;
    }
    cout<< "Interfaz Elegida :" << avail_ifaces->name<< endl; 
    setDeviceName(iface, avail_ifaces->name);
    GetMACAdapter(iface);
}

void mostrarMAC(unsigned char  v[6]){
    cout<<"La MAC es: ";
       for(int i=0;i<6;i++){
           if(i==5){
               printf("%X", v[i]);
           }
           else if (i<5){
               printf("%X:", v[i]);
           }
       }
       cout<<endl;
   
   
   }

int seleccionarGrupo() {
    printf("Introduzca el numero de grupo:\n");
    int grupo;
    cin>>grupo;
    return grupo;
}

void seleccionarModo(interface_t *iface, int g){
    int n; 
    char numTrama='0';
    printf("Selección el modo de la estación\n");
    printf("[1] Modo Maestro\n");
    printf("[2] Modo Esclavo\n");
    cin>>n; //modo
    if(n!=27){
        if(n==1){
            pdMaestro(iface,g, n);
            
        }
        else if (n==2){
            pdEsclavo(iface, g, n);
        }   
    }
}
   void enviarTrama(interface_t *iface, char *car, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]){
   unsigned char * tramaEnviada = BuildFrame(mac_src, mac_dst, type, (unsigned char*)car);
   SendFrame(iface, tramaEnviada, 1);
   free(tramaEnviada);
   }


char recibirCaracter(interface_t *iface,unsigned char type[2]){
    //char car;
    assembled_Packet tramaRecibida =  ReceiveFrame(iface);
    int tam = tramaRecibida.header.len - 14; //tamaño del paquete :  macsrc(6), macdst(6), type(2), datos(resto)
    const unsigned char* data = tramaRecibida.packet; //paquete de X tamaño
    if(data){
         if(data[12]==type[0] && data[13]==0x00){
            printf("Caracteres recibidos: %i\n", tam);
            return data[14];
        }
    }
    return 0;
}


void envioCaracteresInteractivo(interface_t *iface,unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2]){
    char tecla;
    __fpurge(stdin);
    cout<<"Pulse los caracteres a enviar:\n"<<endl;

    while(tecla!=27){
        //Recibir trama
     char car = recibirCaracter(iface, type);
        if(car!=0){
            printf("Recibido %c\n", car);
        }
        
        if(kbhit()){ //Enviar trama
            tecla=getch();
            if(tecla!=27){
                //Enviamos un carácter
                enviarTrama(iface,&tecla,mac_src,mac_dst,type);
            }
        }
      
    }
}

int recibirCadena(interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2], char cadena[255]){
    assembled_Packet tramaRecibida =  ReceiveFrame(iface);
    int tam = tramaRecibida.header.len - 14; //tamaño del paquete :  macsrc(6), macdst(6), type(2), datos(resto)

    const unsigned char* data = tramaRecibida.packet; //paquete de X tamaño
    
    if(data){
        if(tam > 0){
        if(data[12]==type[0] && data[13]==0x00){         
            printf("Mensaje recibido\n");
            printf("Caracteres recibidos: %i\n", tam);

            memcpy(cadena, data+14, tam);
            cadena [tam] = '\0';
            int ncars = tam;
            return ncars;
        }
        
    }
}
    return 0;
}

unsigned char calculoBCE(char cad[255]){
    unsigned char bce = cad[0];
    
    for(int i = 1; i < strlen(cad); i++){
        bce = bce ^ cad[i];
    }

    if(bce==0 || bce==255){
        bce = 1;
    }

    return bce;

}

void borrarFichero() {
    ofstream fichero("RProtoc.txt", ios::out | ios::trunc);
    if (fichero.is_open()) {
        fichero.close();
    }
}

void seleccion(int n, interface_t *iface, unsigned char mac_src[6], unsigned char mac_dst[6], unsigned char type[2], int &error){
    bool salir = false;
    int tecla;
    int tec;
    char cadena [255];
    int num=0;

    if(n==1){
        printf("Selección de modo:\n"
        "[F1] - Envio de caracter interactivo\n"
        "[F2] - Envio de un fichero\n"
        "[F3] - Protocolo de para y espera - Seleccion \n"
        "[F4] - Introduccion errores durante protocolo \n"
        "[ESC] - Salir\n");
    }else if(n==2){
        printf("Selección de modo:\n"
        "[F1] - Envio de caracter interactivo\n"
        "[F3] - Protocolo de para y espera - Seleccion\n"
        "[ESC] - Salir\n");
    }

    while(!salir){
        if(n==2){
            if(recibirCadena(iface, mac_src, mac_dst, type, cadena)!=0){
                cout<<cadena<<endl;
                num=1;
            }else if(num==1 && recibirCadena(iface, mac_src, mac_dst, type, cadena)==0){
                num=0;
                printf("\n");
                seleccion(n, iface, mac_src, mac_dst, type, error);
            }
        }

        if(kbhit()){
            tecla=getch();
            if(tecla!=27){

            }else{
                if(kbhit()){
                    tec=getch();
                    if(tec=='O'){
                        int t=getch();
                        switch(t){
                            case 'P':
                                envioCaracteresInteractivo(iface, mac_src, mac_dst, type);
                                if(n==1){
                                    seleccion(n, iface, mac_src, mac_dst, type, error);
                                }else if(n==2){
                                    seleccion(n, iface, mac_src, mac_dst, type, error);
                                }
                                break;
                            case 'Q':
                                if(n==1){
                                    envioDeFichero(iface, mac_src, mac_dst, type);
                                    seleccion(n, iface, mac_src, mac_dst, type, error);
                                }
                                break;
                            case 'R':
                                cout<<endl;
                                printf("Protocolo paro y espera\n");
                                if(n==1){
                                    printf("Estas en modo maestro\n");
                                    establecimientoMaestro(iface, mac_src, mac_dst, type);
                                    transferenciaMaestro(iface, mac_src, mac_dst, type, error);
                                    liberacionMaestro(iface, mac_src, mac_dst, type);
                                    printf("Fin de Seleccion por parte del maestro\n");
                                    seleccion(n, iface, mac_src, mac_dst, type, error);
                                }else{
                                    printf("Estas en modo esclavo\n");
                                    paroYEsperaEsclavo(iface, mac_src, mac_dst, type);
                                    printf("Fin de Seleccion por parte del esclavo\n");
                                    seleccion(n, iface, mac_src, mac_dst, type, error);
                                }
                                break;
      
                        }  
                        
                    }
                }else{
                    salir=true;
                }
            }
        }
    }   
}

